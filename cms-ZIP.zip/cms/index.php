<?php include("includes/meta.php"); ?>
<?php include("includes/header.php"); ?>

<main class="flex-shrink-0">
  <div class="container">
    <div id="card-items" class="row row-cols-1 row-cols-md-4 row-cols-sm-2 g-4"></div>
  </div>
</main>

<script>
  document.getElementsByTagName("title")[0].innerText = 'CMS';
</script>
<script src="assets/js/home.js"></script>
<?php include("includes/footer.php"); ?>
