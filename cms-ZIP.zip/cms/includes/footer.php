<footer class="footer mt-auto py-3 fixed-bottom bg-light" style="background-color: #2e5e88ff">
    <div class="container">
        <span id="footer-content" class="text-muted">©️ 2021 Copyright: cms.com</span>
    </div>
</footer>

<?php include("footer-empty.php");?>
